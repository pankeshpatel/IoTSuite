package iotsuite.common;

public interface DeviceStartup {

	/** Called to start the device */
	public void startDevice(Object obj, Object context);

}
