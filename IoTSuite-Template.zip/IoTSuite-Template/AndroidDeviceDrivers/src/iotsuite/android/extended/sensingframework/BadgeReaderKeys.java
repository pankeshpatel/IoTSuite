package iotsuite.android.extended.sensingframework;

public interface BadgeReaderKeys {
	public static final String BadgeDetectedEvent = "badgeDetectedEvent";
	public static final String BadgeDisappearedEvent = "badgeDisappearedEvent";
	public static final String BADGEID = "badgeID";
}
