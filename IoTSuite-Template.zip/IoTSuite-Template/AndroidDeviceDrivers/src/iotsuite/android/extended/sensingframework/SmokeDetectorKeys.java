package iotsuite.android.extended.sensingframework;

public interface SmokeDetectorKeys {
	public static final String SmokeMeasurementEvent = "badgeDetectedEvent";
	//public static final String BadgeDisappearedEvent = "badgeDisappearedEvent";
	public static final String BADGEID = "badgeID";
}
