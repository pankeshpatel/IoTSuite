package iotsuite.android.extended.sensingframework;

public interface HumiditySensorKeys {
	public static final String HumiditySensorEvent = "badgeDetectedEvent";
	//public static final String BadgeDisappearedEvent = "badgeDisappearedEvent";
	public static final String BADGEID = "badgeID";
}
